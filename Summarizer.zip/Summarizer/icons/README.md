<!-- This is a placeholder for icon16.png -->
<!-- You need to create actual PNG icon files with these sizes: -->
<!-- icon16.png - 16x16 pixels -->
<!-- icon32.png - 32x32 pixels -->
<!-- icon48.png - 48x48 pixels -->
<!-- icon128.png - 128x128 pixels -->

<!-- Icon should represent a document/summarizer theme -->
<!-- Suggested design: A document with a sparkle or AI symbol -->
<!-- Use tools like Canva, Figma, or GIMP to create these icons -->
